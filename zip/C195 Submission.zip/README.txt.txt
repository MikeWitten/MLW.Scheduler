•  title and purpose of the application
	Title:		"Desktop Scheduling Application"
	Purpose:	Allows a user to add or manipulate appointments and customers to the company database.


•  author, contact information, student application version, and date
	Author: 	Micheal L Witten
	Contact:	mwitte5@wgu.edu  
	Version:	1.0
	Date:		5 May 2022
	

•  IDE including version number (e.g., IntelliJ Community 2020.01), full JDK of version used (e.g., Java SE 17.0.1), and JavaFX version compatible with JDK version (e.g. JavaFX-SDK-17.0.1)
	IDE:		IntelliJ Community 2022.1
	JDK:		Java SE 17.0.2
	JavaFX:		JavaFX-SDK 17.0.1


•  directions for how to run the program
	Directions:  	Main pages for managing appointments and customers can be found on the homepage.
			Additional reports for contacts and users are found in the appointment details section, which can be accessed through multiple tables throughout the program.
			Reports for countries and first level divisions can be accessed through the customer detail page, which can be accessed through the customer management and appointment details pages.
			The log in form is available in French and English.
			The homepage alerts the user of upcomming appointments.
			Log in credentials with 'admin'/'admin or 'test'/'test'.


•  a description of the additional report of your choice you ran in part A3f
	Reports:	Additional reports for user's, countries, customers, and first level divisions are available.  Each has an associated table with appointments, customers, or divisions.



•  the MySQL Connector driver version number, including the update number (e.g., mysql-connector-java-8.1.23)
	SQL connector:	mysql-connector-java-8.0.282